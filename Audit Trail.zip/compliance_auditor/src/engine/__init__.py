"""
Compliance rule engine package.
"""